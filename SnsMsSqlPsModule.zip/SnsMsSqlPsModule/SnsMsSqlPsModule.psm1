
If ($true)
{
[System.Object]$objPsGalMdl = $null;
Try { [System.Object]$objPsGalMdl = Find-Module -Name "SnsMsSqlPsModule" -Repository "PSGallery" -ErrorAction "Stop"; } Catch {};
[System.Array]$arrLocMdl = @();
[System.Array]$arrLocMdl = Get-Module -Name "SnsMsSqlPsModule" -ListAvailable;
If ((-not -not "$($objPsGalMdl.Version)") -and ("$($arrLocMdl[0].Version)" -ne "$($objPsGalMdl.Version)"))
{ Write-Warning "Module ""SnsMsSqlPsModule"" Have Newer Version. Please Update It."; }
}

((Get-Host).UI.RawUI).WindowTitle = "SnsMsSqlPsModule - Created by Svetoslav Savov";
((Get-Host).UI.RawUI).BufferSize.Width = 120;
((Get-Host).UI.RawUI).BufferSize.Height = 50;
((Get-Host).UI.RawUI).WindowSize.Width = 120;
((Get-Host).UI.RawUI).WindowSize.Height = 50;
((Get-Host).UI.RawUI).MaxWindowSize.Width = 120;
((Get-Host).UI.RawUI).MaxWindowSize.Height = 50;

If (([System.Environment]::UserInteractive) -and (-not "$($MyInvocation.PSCommandPath)"))
{
[System.Text.StringBuilder]$strMsg = New-Object -TypeName "System.Text.StringBuilder" -Verbose:$false -Debug:$false -ArgumentList @(150);
[void]$strMsg.Append("`r`n$('*' * 100)`r`n*$(' ' * 98)*`r`n");
[void]$strMsg.Append("*$(' ' * 31)SnsMsSqlPsModule - PowerShell Module$(' ' * 31)*`r`n");
[void]$strMsg.Append("*$(' ' * 37)ModuleVersion - 0.0.0.5$(' ' * 38)*`r`n*$(' ' * 98)*`r`n");
[void]$strMsg.Append("*$(' ' * 9)AUTHOR:    Svetoslav Nedyalkov Savov$(' ' * 53)*`r`n");
[void]$strMsg.Append("*$(' ' * 9)THIS CODE IS MADE AVAILABLE AS IS, WITHOUT WARRANTY OF ANY KIND. THE ENTIRE RISK$(' ' * 9)*`r`n");
[void]$strMsg.Append("*$(' ' * 9)OF THE USE OR THE RESULTS FROM THE USE OF THIS CODE REMAINS WITH THE USER.$(' ' * 15)*`r`n");
[void]$strMsg.Append("*$(' ' * 98)*`r`n$('*' * 100)`r`n`r`n");
Write-Host "$($strMsg.ToString())" -ForegroundColor 'Green';
Remove-Variable -Force -WhatIf:$false -Confirm:$false -ErrorAction "SilentlyContinue" -Name "strMsg";
}
